(function () {
    'use strict';
    angular.module('com.vyom.vyomlib.view-components.pwidget', [
        'com.bmc.arsys.rx.standardlib.security',
        'com.bmc.arsys.rx.standardlib.view-component',
        'com.bmc.arsys.rx.standardlib.record.definition',
        'com.bmc.arsys.rx.standardlib.record.instance'
    ]);
})();
